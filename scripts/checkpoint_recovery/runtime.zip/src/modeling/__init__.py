"""Canonical corrected modeling package."""
